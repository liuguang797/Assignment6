import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class PetList2014302580120 extends JFrame {

	private JPanel contentPane;
	private final JScrollPane scrollPane = new JScrollPane();
	private JTable table;
	private String username;
	public Object[][] petToBuy = new Object[12][3];

	
	
	/**
	 * Create the frame.
	 * @return 
	 * @return 
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public PetList2014302580120(String name) throws ClassNotFoundException, SQLException {
		this.username = name;
		setTitle("�����̵�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		scrollPane.setBounds(10, 10, 614, 496);
		contentPane.add(scrollPane);
		
		table = new JTable();
		
		Object[][] dataObj = getPet();
		
		DefaultTableModel tmodel = new DefaultTableModel(
				dataObj,
				new String[] {
						"Number", "pic", "name", "eat", "drink", "live", "hobby", "Price",
				}
			) {
			Class[] columnTypes = new Class[] {
				Boolean.class, ImageIcon.class, Object.class, Object.class, Object.class, Object.class, Object.class, Float.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				true, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		};
		
		table.setModel(tmodel);
		
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.getColumnModel().getColumn(1).setPreferredWidth(50);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(2).setPreferredWidth(50);
		table.getColumnModel().getColumn(3).setResizable(false);
		table.getColumnModel().getColumn(3).setPreferredWidth(85);
		table.getColumnModel().getColumn(4).setResizable(false);
		table.getColumnModel().getColumn(4).setPreferredWidth(50);
		table.getColumnModel().getColumn(5).setResizable(false);
		table.getColumnModel().getColumn(5).setPreferredWidth(125);
		table.getColumnModel().getColumn(6).setResizable(false);
		table.getColumnModel().getColumn(6).setPreferredWidth(50);
		table.getColumnModel().getColumn(7).setResizable(false);
		table.getColumnModel().getColumn(7).setPreferredWidth(50);
		
		scrollPane.setViewportView(table);
		table.setRowHeight(50);
		
		
		
		/*
		 * ���ӳ���ͼƬ	
		 */
		for (int i=1; i<=12; i++) {
			table.setValueAt(new ImageIcon("pic\\" +i + ".jpg"), i-1, 1);
		}
		
		/*
		 * ��ת�����ﳵҳ��
		 */
		JButton btnShoppingCart = new JButton("���ﳵ");
		btnShoppingCart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					setVisible(false);
					ShoppingCart2014302580120 frame = new ShoppingCart2014302580120(username);
					frame.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
				

			}
		});
		
		btnShoppingCart.setBounds(354, 516, 130, 36);
		contentPane.add(btnShoppingCart);
		
		/*
		 * ����Ʒ���빺�ﳵ
		 */
		JButton btnAdd = new JButton("���빺�ﳵ");
		btnAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					petToBuy = getPetInCart();
					for (int i=1; i<=12; i++) {
						if (table.getValueAt(i-1, 0) != null) {
							petToBuy[i-1][2] = Integer.parseInt(petToBuy[i-1][2].toString()) + 1;

							table.setValueAt(null, i-1, 0); 
						}
					}
					
					/*
					 * �������ݿ⹺�ﳵ����
					 */
					DBReader2014302580120 db = new DBReader2014302580120();
					Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
							
					for (int i=0; i<12; i++) {
						String sql = "update 2014302580120_cart set number=?  where user_name=? and pet_name=?";
						PreparedStatement sta = conn.prepareStatement(sql);
						sta.setInt(1, Integer.parseInt(petToBuy[i][2].toString()));
						sta.setString(2, petToBuy[i][0].toString());
						sta.setString(3, petToBuy[i][1].toString());
						sta.executeUpdate();
					}
					
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}				
				JOptionPane.showMessageDialog(contentPane, "�ѳɹ����빺�ﳵ", "���ӳɹ�", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnAdd.setBounds(119, 516, 130, 36);
		contentPane.add(btnAdd);
		
	}
	
	/**
	 * �����ݿ��ȡ������Ϣ
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private Object[][] getPet() throws ClassNotFoundException, SQLException {
		
		DBReader2014302580120 db = new DBReader2014302580120();
		Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
		
		String sql = "select * from 2014302580120_pet";
		
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(sql);
		
		int i = 1;
		Object[][] dataObj = new Object[12][8];
		
		while (rs.next()) {
			dataObj[i-1][2] = rs.getString(2);
			dataObj[i-1][3] = rs.getString(3);
			dataObj[i-1][4] = rs.getString(4);
			dataObj[i-1][5] = rs.getString(5);
			dataObj[i-1][6] = rs.getString(6);
			dataObj[i-1][7] = rs.getDouble(7); //price
			i++;
		}
		
		return dataObj;
		
	}
	
	/**
	 * ��ȡ���ﳵ����Ʒ
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Object[][] getPetInCart() throws ClassNotFoundException, SQLException {
		Object[][] petInCart = new Object[12][3];
		DBReader2014302580120 db = new DBReader2014302580120();
		Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
		
		String sql = "select * from 2014302580120_cart";
		
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(sql);
		
		int i = 1;
		while (rs.next()) {
			if (username.equals(rs.getString(2))) {
				petInCart[i-1][0] = rs.getString(2); //username
				petInCart[i-1][1] = rs.getString(3); //pet_name
				petInCart[i-1][2] = rs.getInt(4); //number
				
				i++;
			}
		}
		return petInCart;
	}

	
}
