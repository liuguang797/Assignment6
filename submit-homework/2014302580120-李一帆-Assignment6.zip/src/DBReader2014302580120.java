import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBReader2014302580120 {
	private String DBAddress;
	Connection mycon;
	private String username = "root";
	private String pwd = "123456";
	
	/**
	 * �������ݿ⣬ ��������״̬
	 * @param DBAdress
	 * @return Connection
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Connection getConnection(String DBAdress) throws ClassNotFoundException, SQLException {
		this.DBAddress = DBAdress;
		
		Class.forName("com.mysql.jdbc.Driver");
		mycon = DriverManager.getConnection(DBAddress, username, pwd);
		return mycon;
				
	}
	
	/**
	 * �������ݿ�
	 * @param sql
	 * @param data
	 * @throws SQLException
	 */
	public void insert(String sql, Object[] data) throws SQLException {
		PreparedStatement sta = mycon.prepareStatement(sql);
		for (int i=0; i<data.length; i++) {
			sta.setObject(i+1, data[i]);
		}
		sta.executeUpdate();
	}

}
