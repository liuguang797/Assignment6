import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class login2014302580120 extends JFrame {

	private JPanel contentPane;
	private JTextField tfName;
	private JTextField tfPwd;


	/**
	 * Create the frame.
	 */
	public login2014302580120() {
		setTitle("��¼");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("������");
		lblName.setBounds(83, 51, 54, 25);
		contentPane.add(lblName);
		
		JLabel lblpwd = new JLabel("����");
		lblpwd.setBounds(83, 127, 54, 25);
		contentPane.add(lblpwd);
		
		tfName = new JTextField();
		tfName.setBounds(159, 51, 170, 25);
		contentPane.add(tfName);
		tfName.setColumns(10);
		
		tfPwd = new JPasswordField();
		tfPwd.setBounds(159, 127, 170, 25);
		contentPane.add(tfPwd);
		tfPwd.setColumns(10);
		
		/*
		 * ����ע��ҳ��
		 */
		JButton btnSignUp = new JButton("ע��");
		btnSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							setVisible(false);
							signUp2014302580120 frame = new signUp2014302580120();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		btnSignUp.setBounds(67, 209, 100, 30);
		contentPane.add(btnSignUp);
		
		/*
		 * ��¼����ʵ��
		 */
		JButton btnLogin = new JButton("��½");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String name = tfName.getText().toString();
				String pwd = tfPwd.getText().toString();
				
				/*
				 * �ж������������ֶ��Ƿ�Ϊ��
				 */
				if (name==null || pwd==null || name.equals("") || pwd.equals("")) {
					JOptionPane.showMessageDialog(contentPane, "�������û���������", "����", JOptionPane.ERROR_MESSAGE);
				}else {
					DBReader2014302580120 db = new DBReader2014302580120();
					boolean userExist = false;
					
					try {
						Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
						Statement st = conn.createStatement();
						String sql = "select * from 2014302580120_user";
						ResultSet rs = st.executeQuery(sql);
						/*
						 * �����û�
						 */
						while (rs.next()) {
							if (name.equals(rs.getString(2))) {
								userExist = true;
								/*
								 * �����û����ж������Ƿ���ȷ
								 */
								if (pwd.equals(rs.getString(3))) {
									setVisible(false);
									PetList2014302580120 frame = new PetList2014302580120(name);
									frame.setVisible(true);
	
									

								}else {
									JOptionPane.showMessageDialog(contentPane, "�������", "����", JOptionPane.ERROR_MESSAGE);

								}
							}
						}
						
						/*
						 * userExistΪfalse������������δע�� 
						 */
						if (userExist) {
							
						}else {
							JOptionPane.showMessageDialog(contentPane, "���û�����δע��", "����", JOptionPane.ERROR_MESSAGE);
						}
						
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
				}
					
				
				
			}
		});
		btnLogin.setBounds(254, 209, 100, 30);
		contentPane.add(btnLogin);
	}

}
