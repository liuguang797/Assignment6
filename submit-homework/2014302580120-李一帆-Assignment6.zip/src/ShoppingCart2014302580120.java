import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class ShoppingCart2014302580120 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private String username;
	private Object[][] cartPet;
	

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public ShoppingCart2014302580120(String name) throws ClassNotFoundException, SQLException {
		this.username = name;
		setTitle("���ﳵ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 380, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 344, 325);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setRowHeight(25);
		cartPet = getPet();
		System.out.println();
		DefaultTableModel tModel = new DefaultTableModel(
			cartPet,
			new String[] {
				"name", "price", "number"
			}
		) {
			Class[] columnTypes = new Class[] {
				Object.class, Double.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		};
		table.setModel(tModel);
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.getColumnModel().getColumn(2).setResizable(false);
		
		scrollPane.setViewportView(table);
		

		/*
		 * �����̵�ҳ��
		 */
		JButton btnPetList = new JButton("�����̵�");
		btnPetList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				PetList2014302580120 frame;
				try {
					frame = new PetList2014302580120(username);
					frame.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
		
			}
		});
		btnPetList.setBounds(46, 361, 120, 36);
		contentPane.add(btnPetList);
		
		JButton btnBuy = new JButton("ȷ�Ϲ���");
		btnBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnBuy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				/*
				 * �����Ǯ
				 */
				double price = 0.0;
				for (int i=0; i<12; i++) {
					if (cartPet[i][1]!=null) {
						price += Double.parseDouble(cartPet[i][1].toString()) * Integer.parseInt(cartPet[i][2].toString());
						
					}
				}
				
				/*
				 * �����ݿ��й��ﳵ�������
				 */
				DBReader2014302580120 db = new DBReader2014302580120();
				try {
					Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
					for (int i=0; i<12; i++) {
						String sql = "update 2014302580120_cart set number=?  where user_name=?";
						PreparedStatement sta = conn.prepareStatement(sql);
						sta.setInt(1, 0);
						sta.setString(2, username);
						sta.executeUpdate();
					}
					
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}

				JOptionPane.showMessageDialog(contentPane, "�ѳɹ�����"+'\n' + "������"+price+"Ԫ"+'\n' + "�����Զ���ת�������̵�ҳ��", "���ӳɹ�", JOptionPane.INFORMATION_MESSAGE);
				
				setVisible(false);
				
				try {
					PetList2014302580120 frame = new PetList2014302580120(username);
					frame.setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
				
			}
		});
		btnBuy.setBounds(191, 361, 120, 36);
		contentPane.add(btnBuy);
	}
	
	/**
	 * ��ȡ���ﳵ����Ʒ��չʾ
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private Object[][] getPet() throws ClassNotFoundException, SQLException {
		
		DBReader2014302580120 db = new DBReader2014302580120();
		Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
		
		String sql = "select * from 2014302580120_cart";
		
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(sql);
		
		int i = 1;
		Object[][] dataObj = new Object[12][3];
		
		while (rs.next()) {
			if (username.equals(rs.getString(2))) {
				if (rs.getInt(4)!=0) {
				dataObj[i-1][0] = rs.getString(3); //pet_name
				dataObj[i-1][1] = rs.getDouble(5); //price
				dataObj[i-1][2] = rs.getInt(4); //number
				i++;
				}
			}
		}
		
		return dataObj;
		
	}
}
