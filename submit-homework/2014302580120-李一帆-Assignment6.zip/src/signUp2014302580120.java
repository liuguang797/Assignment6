import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class signUp2014302580120 extends JFrame {

	private JPanel contentPane;
	private JTextField tfName;
	private JTextField tfPwd;
	private JTextField tfRePwd;


	/**
	 * Create the frame.
	 */
	public signUp2014302580120() {
		setTitle("ע��");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tfName = new JTextField();
		tfName.setBounds(157, 25, 170, 25);
		contentPane.add(tfName);
		tfName.setColumns(10);
		
		tfPwd = new JPasswordField();
		tfPwd.setBounds(157, 87, 170, 25);
		contentPane.add(tfPwd);
		tfPwd.setColumns(10);
		
		tfRePwd = new JPasswordField();
		tfRePwd.setBounds(157, 145, 170, 25);
		contentPane.add(tfRePwd);
		tfRePwd.setColumns(10);
		
		JLabel lblName = new JLabel("����:");
		lblName.setBounds(81, 25, 54, 25);
		contentPane.add(lblName);
		
		JLabel lblPwd = new JLabel("����:");
		lblPwd.setBounds(81, 87, 54, 25);
		contentPane.add(lblPwd);
		
		JLabel lblRePwd = new JLabel("�ٴ���������:");
		lblRePwd.setBounds(64, 145, 93, 25);
		contentPane.add(lblRePwd);
		
		/*
		 * ע��
		 */
		JButton btnSignUp = new JButton("ȷ��ע��");
		btnSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String name = tfName.getText().toString();
				String pwd = tfPwd.getText().toString();
				String rePwd = tfRePwd.getText().toString();
				
				/*
				 * �ж������ֶηǿ�
				 */
				if (name==null || pwd==null || rePwd==null || name.equals("") || pwd.equals("") || rePwd.equals("")) {
					JOptionPane.showMessageDialog(contentPane, "�����Ϊ�����ֶ�", "����", JOptionPane.ERROR_MESSAGE);
				}else {
					DBReader2014302580120 db = new DBReader2014302580120();
					
					/*
					 * �鿴�����Ƿ�ռ��
					 */
					boolean nameUsable = true;
					
					try {
						Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
						Statement st = conn.createStatement();
						String sql = "select * from 2014302580120_user";
						ResultSet rs = st.executeQuery(sql);
						while (rs.next()) {
							if (name.equals(rs.getString(2))) {
								JOptionPane.showMessageDialog(contentPane, "�����ѱ�ռ��", "����", JOptionPane.ERROR_MESSAGE);
								nameUsable = false;
								break;
							}
						}
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
					
					/*
					 * ������δ��ռ����ע�����û�
					 */
					if (nameUsable) {
						if (pwd.equals(rePwd)) {
							
							try {
								Object[] newUser = {name, pwd, 1000000};
								db.insert("insert into 2014302580120_user(name, pwd, account) value(?, ?, ?)", newUser);
								
								initCart(name);
								
								JOptionPane.showMessageDialog(contentPane, "ע��ɹ�" + '\n' + "�������ص�½��ť���е�¼", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
							} catch (ClassNotFoundException |SQLException e1) {
								e1.printStackTrace();
								JOptionPane.showMessageDialog(contentPane, "��Ŷ�����ݿ���˵�С��������һ�ΰ�", "����", JOptionPane.ERROR_MESSAGE);
							} 
							
						}else {
							JOptionPane.showMessageDialog(contentPane, "�����������벻һ��", "����", JOptionPane.ERROR_MESSAGE);
						
						}
					}
				}
				
			}
		});
		btnSignUp.setBounds(263, 204, 100, 30);
		contentPane.add(btnSignUp);
		
		/*
		 * ���ص�¼����
		 */
		JButton btnLogin = new JButton("���ص�½");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setVisible(false);
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							setVisible(false);
							login2014302580120 frame = new login2014302580120();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		btnLogin.setBounds(64, 204, 100, 30);
		contentPane.add(btnLogin);
	}
	
	/**
	 * ��ʼ�����ﳵ����
	 * @param username
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public void initCart(String username) throws ClassNotFoundException, SQLException {
		DBReader2014302580120 db = new DBReader2014302580120();
		Connection conn = db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema");
		String sql = "select * from 2014302580120_pet";
		
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(sql);
		Object[][] data = new Object[12][4];
		int i = 0;
		while (rs.next()) {
			data[i][0] = username;
			data[i][1] = rs.getString(2);
			data[i][2] = 0;
			data[i][3] = rs.getDouble(7);
			i++;
		}
		
		for (int num=0; num<data.length; num++) {
			db.insert("insert into 2014302580120_cart(user_name, pet_name, number, price) value(?, ?, ?, ?)", data[num]);
		}
		
	}
}
