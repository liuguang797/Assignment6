-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: my_schema
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `2014302580120_cart`
--

LOCK TABLES `2014302580120_cart` WRITE;
/*!40000 ALTER TABLE `2014302580120_cart` DISABLE KEYS */;
INSERT INTO `2014302580120_cart` VALUES (27,'11','dog',2,55),(28,'11','cat',3,43),(29,'11','turtle',1,132),(30,'11','parrot',0,54),(31,'11','hamster',0,87),(32,'11','squirrel',0,45),(33,'11','rabbit',0,33),(34,'11','snake',0,38),(35,'11','lizard',0,187),(36,'11','fish',0,57),(37,'11','myna',0,94),(38,'11','canary',0,68),(39,'22','dog',0,55),(40,'22','cat',0,43),(41,'22','turtle',0,132),(42,'22','parrot',0,54),(43,'22','hamster',0,87),(44,'22','squirrel',0,45),(45,'22','rabbit',0,33),(46,'22','snake',0,38),(47,'22','lizard',0,187),(48,'22','fish',0,57),(49,'22','myna',0,94),(50,'22','canary',0,68);
/*!40000 ALTER TABLE `2014302580120_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_schema'
--

--
-- Dumping routines for database 'my_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-13 22:37:02
